# crud-example php
-----------------------------------------------------------------------------------------------------------------------------------------

SIMPLE CRUD EXAMPLE FROM SCRATH, USING MVC DESIGN PATTERN AND OO

CREATE    -> CREATE NEW ENTITY <br>
RETRIEVE  -> GET DATA FROM EXISTING ENTITY <br>
UPDATE    -> UPDATE THE DATA FROM EXISTING ENTITY | CREATE NEW ENTITY<br>
DELETE    -> DELETE ENTITY.  <br>

THANK YOU FOR github.com.
